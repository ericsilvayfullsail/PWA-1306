/*
	PWA1: Goal7:  Simple Library
*/

var YOURLIBNAME = function(){

    return new YOURLIBNAME.prototype.init();

};

YOURLIBNAME.prototype = {

    init: function(){},

    elements: []

}; // end prototype

YOURLIBNAME.prototype.init.prototype = YOURLIBNAME.prototype;