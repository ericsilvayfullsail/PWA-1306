/*
	PWA1: Goal7: Simple Library App
*/

(function(){


})();  // end wrapper